
# 1. SETUP AND IMPORT LIBRARIES

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns


# 2. CREATE AND LOAD DATA

data = {
    'product_id': range(1, 101),
    'product_name': ['Lipstick', 'Foundation', 'Mascara', 'Eyeliner', 'Blush'] * 20,
    'shade': ['Ruby Red', 'Nude Beige', 'Jet Black', 'Chocolate Brown', 'Rose Pink'] * 20,
    'unit_price': np.random.uniform(15.50, 45.99, 100).round(2),
    'units_sold': np.random.randint(50, 500, 100),
    'rating': np.random.uniform(3.5, 5.0, 100).round(1),
    'region': ['North', 'South', 'East', 'West'] * 25
}

df = pd.DataFrame(data)

# Let's introduce some missing values for our cleaning demonstration
df.loc[5, 'rating'] = np.nan
df.loc[15, 'rating'] = np.nan
df.loc[25, 'units_sold'] = np.nan



print("DATASET PREVIEW (TOP 5 ROWS)")

print(df.head())
print("\n")



# 3. DATA CLEANING AND PREPROCESSING

print("DATA CLEANING & PROCESSING")


# Check for missing values
print("Missing values before cleaning:")
print(df.isnull().sum())
print("\n")


mean_rating = df['rating'].mean()
df['rating'].fillna(mean_rating, inplace=True)

# For 'units_sold', we'll fill with the median, which is better for skewed data.
median_units_sold = df['units_sold'].median()
df['units_sold'].fillna(median_units_sold, inplace=True)

print("Missing values after cleaning:")
print(df.isnull().sum())
print("\n")


#Adding New Columns

df['total_revenue'] = df['unit_price'] * df['units_sold']

print("Dataset preview after adding 'total_revenue' column:")
print(df.head())
print("\n")



# 4. EXPLORATORY DATA ANALYSIS (EDA)


print("EXPLORATORY DATA ANALYSIS (EDA)")


# --- Summary Statistics ---
# Get a statistical summary of the numerical columns.
print("Statistical Summary of Numerical Data:")
print(df.describe())
print("\n")


#Value Counts

print("Product Sales Distribution:")
print(df['product_name'].value_counts())
print("\n")


#rouping and Aggregation

avg_revenue_per_product = df.groupby('product_name')['total_revenue'].mean().round(2).sort_values(ascending=False)
print("Average Revenue per Product:")
print(avg_revenue_per_product)
print("\n")

# Find the total units sold per region.
units_sold_per_region = df.groupby('region')['units_sold'].sum().sort_values(ascending=False)
print("Total Units Sold per Region:")
print(units_sold_per_region)
print("\n")



# 5. DATA VISUALIZATION


print("GENERATING VISUALIZATIONS")

# The plots will be displayed in separate windows when you run this script.

# Set a nice style for the plots
sns.set_theme(style="whitegrid")


# --- Plot 1: Histogram of Product Ratings ---
plt.figure(figsize=(10, 6))
sns.histplot(data=df, x='rating', bins=15, kde=True)
plt.title('Distribution of Product Ratings', fontsize=16)
plt.xlabel('Rating (out of 5.0)')
plt.ylabel('Number of Products')
plt.show()


# --- Plot 2: Bar Chart of Total Revenue by Product ---
plt.figure(figsize=(12, 7))
# Use the grouped data we created earlier
total_revenue_by_product = df.groupby('product_name')['total_revenue'].sum().sort_values(ascending=False)
sns.barplot(x=total_revenue_by_product.index, y=total_revenue_by_product.values)
plt.title('Total Revenue by Product Name', fontsize=16)
plt.xlabel('Product Name')
plt.ylabel('Total Revenue ($)')
plt.xticks(rotation=45)
plt.show()


# --- Plot 3: Scatter Plot of Price vs. Units Sold ---
plt.figure(figsize=(10, 6))
sns.scatterplot(data=df, x='unit_price', y='units_sold', hue='product_name', palette='viridis', s=100, alpha=0.7)
plt.title('Unit Price vs. Units Sold', fontsize=16)
plt.xlabel('Unit Price ($)')
plt.ylabel('Units Sold')
plt.legend(title='Product Name')
plt.show()


# --- Plot 4: Box Plot of Ratings by Region ---
plt.figure(figsize=(12, 7))
sns.boxplot(data=df, x='region', y='rating')
plt.title('Product Ratings Across Different Regions', fontsize=16)
plt.xlabel('Region')
plt.ylabel('Rating')
plt.show()


print("ANALYSIS COMPLETE")
