# GlamourGlow Cosmetics - Supply Chain Performance Analytics

This repository contains the data analysis and visualization code for the GlamourGlow Cosmetics supply chain performance review. The goal is to identify inefficiencies in inventory, fulfillment, and supplier management and provide actionable recommendations.

## 📊 Project Overview

This analysis focuses on:
-   **Inventory Health:** Identifying overstocking and stockout patterns.
-   **Supplier Performance:** Analyzing defect rates and lead times.
-   **Fulfillment Efficiency:** Tracking on-time delivery rates and regional lags.
-   **Cost Drivers:** Visualizing operational costs and their impact on profitability.

## 🛠️ Setup and Installation

To run this analysis, clone the repository and install the required dependencies.

1.  **Clone the repository:**
    ```bash
    git clone [https://github.com/your-username/glamourglow-cosmetics-analysis.git](https://github.com/your-username/glamourglow-cosmetics-analysis.git)
    cd glamourglow-cosmetics-analysis
    ```

2.  **Create a virtual environment (recommended):**
    ```bash
    python -m venv venv
    source venv/bin/activate  # On Windows, use `venv\Scripts\activate`
    ```

3.  **Install the required packages:**
    ```bash
    pip install -r requirements.txt
    ```

## 🚀 How to Run the Analysis

The main analysis is located in the `notebooks/` directory.

1.  Place your raw data file (e.g., `glamourglow_sales_data.csv`) inside the `data/raw/` directory.
2.  Open and run the Jupyter Notebook:
    ```bash
    jupyter notebook notebooks/01_exploratory_data_analysis.ipynb
    ```

## 📈 Key Findings

-   **Revenue:** Foundations are the highest revenue-generating product category.
-   **Ratings:** Most products maintain a high average rating of 4.0 or above.
-   **Regional Performance:** The "North" region has the highest total units sold.

(Add more insights from your analysis here)